# GUI-based Contact Book using Tkinter

import tkinter as tk
from tkinter import messagebox

class Contact:
    def __init__(self, name, phone, email, address):
        self.name = name
        self.phone = phone
        self.email = email
        self.address = address

class ContactBook:
    def __init__(self, root):
        self.root = root
        self.root.title("Contact Book")

        self.contacts = []

        self.name_label = tk.Label(root, text="Name:")
        self.name_label.grid(row=0, column=0)
        self.name_entry = tk.Entry(root)
        self.name_entry.grid(row=0, column=1)

        self.phone_label = tk.Label(root, text="Phone:")
        self.phone_label.grid(row=1, column=0)
        self.phone_entry = tk.Entry(root)
        self.phone_entry.grid(row=1, column=1)

        self.email_label = tk.Label(root, text="Email:")
        self.email_label.grid(row=2, column=0)
        self.email_entry = tk.Entry(root)
        self.email_entry.grid(row=2, column=1)

        self.address_label = tk.Label(root, text="Address:")
        self.address_label.grid(row=3, column=0)
        self.address_entry = tk.Entry(root)
        self.address_entry.grid(row=3, column=1)

        self.add_button = tk.Button(root, text="Add Contact", command=self.add_contact)
        self.add_button.grid(row=4, column=0, columnspan=2)

        self.view_button = tk.Button(root, text="View Contacts", command=self.view_contacts)
        self.view_button.grid(row=5, column=0, columnspan=2)

        self.search_label = tk.Label(root, text="Search by Name/Phone:")
        self.search_label.grid(row=6, column=0)
        self.search_entry = tk.Entry(root)
        self.search_entry.grid(row=6, column=1)
        self.search_button = tk.Button(root, text="Search", command=self.search_contact)
        self.search_button.grid(row=7, column=0, columnspan=2)

        self.update_button = tk.Button(root, text="Update Contact", command=self.update_contact)
        self.update_button.grid(row=8, column=0, columnspan=2)

        self.delete_button = tk.Button(root, text="Delete Contact", command=self.delete_contact)
        self.delete_button.grid(row=9, column=0, columnspan=2)

        self.result_text = tk.Text(root, height=10, width=40)
        self.result_text.grid(row=10, column=0, columnspan=2)

    def add_contact(self):
        name = self.name_entry.get()
        phone = self.phone_entry.get()
        email = self.email_entry.get()
        address = self.address_entry.get()
        
        if name and phone:
            contact = Contact(name, phone, email, address)
            self.contacts.append(contact)
            self.clear_entries()
            messagebox.showinfo("Success", f"Contact {name} added successfully.")
        else:
            messagebox.showerror("Error", "Name and Phone are required fields.")

    def view_contacts(self):
        self.result_text.delete(1.0, tk.END)
        if not self.contacts:
            self.result_text.insert(tk.END, "No contacts available.\n")
        else:
            for contact in self.contacts:
                self.result_text.insert(tk.END, f"Name: {contact.name}\nPhone: {contact.phone}\nEmail: {contact.email}\nAddress: {contact.address}\n\n")

    def search_contact(self):
        keyword = self.search_entry.get()
        self.result_text.delete(1.0, tk.END)
        found_contacts = [contact for contact in self.contacts if keyword.lower() in contact.name.lower() or keyword in contact.phone]
        if not found_contacts:
            self.result_text.insert(tk.END, "No contacts found.\n")
        else:
            for contact in found_contacts:
                self.result_text.insert(tk.END, f"Name: {contact.name}\nPhone: {contact.phone}\nEmail: {contact.email}\nAddress: {contact.address}\n\n")

    def update_contact(self):
        name = self.name_entry.get()
        for contact in self.contacts:
            if contact.name.lower() == name.lower():
                new_phone = self.phone_entry.get() or contact.phone
                new_email = self.email_entry.get() or contact.email
                new_address = self.address_entry.get() or contact.address

                contact.phone = new_phone
                contact.email = new_email
                contact.address = new_address

                self.clear_entries()
                messagebox.showinfo("Success", f"Contact {contact.name} updated successfully.")
                return
        messagebox.showerror("Error", "Contact not found.")

    def delete_contact(self):
        name = self.name_entry.get()
        for contact in self.contacts:
            if contact.name.lower() == name.lower():
                self.contacts.remove(contact)
                self.clear_entries()
                messagebox.showinfo("Success", f"Contact {contact.name} deleted successfully.")
                return
        messagebox.showerror("Error", "Contact not found.")

    def clear_entries(self):
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)
        self.email_entry.delete(0, tk.END)
        self.address_entry.delete(0, tk.END)
        self.search_entry.delete(0, tk.END)

if __name__ == "__main__":
    root = tk.Tk()
    app = ContactBook(root)
    root.mainloop()
